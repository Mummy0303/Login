import React from "react";
import Form from "./Form";

var userIsRegistered = true;

function App() {
  return (
    <div className="container">
      {userIsRegistered ? <h1>Hello.</h1> : null}
      <Form isRegistered={userIsRegistered} />
    </div>
  );
}

export default App;
